from __future__ import annotations

try:
    from .kar_cli import main as _main
except ImportError:  # pragma: no cover - frozen/standalone entrypoint fallback
    from ksharp.kar_cli import main as _main

__all__ = ["main"]


def main(argv: list[str] | None = None) -> int:
    return _main(argv)


if __name__ == "__main__":
    raise SystemExit(main())
